﻿--------------------------------------------------------------------
* CONFIG.INI *
[Misc]
Armor_Type = {armor1, armor2, armor3, armor4, armor5} // Choose one i.e (Armor_Type = armor5)

armor1 = SuperLightArmor
armor2 = LightArmor
armor3 = StandardArmor
armor4 = HeavyArmor
armor5 = SuperHeavyArmor
--------------------------------------------------------------------
* Hotkeys: (https://www.autohotkey.com/docs/KeyList.htm) *

End		= Activate / Deactivate macro.
Numpad . (Dot)	= Eat snack (P's & Q's).
Numpad 1	= Eat snack (EgoChaser).
Numpad 2	= Eat snack (Meteorite).
Numpad 3	= Eat snack (eCola).
Numpad 0	= Use armor (default: Super Heavy Armor).
Numpad * (Mult)	= Buy ammo.
RCTRL + RSHIFT	= Outfit fix (Re-apply outfit).

Empty public session (via tray menu - The game will be frozen for 10 seconds!).
Diamond Casino Heist Mode (via tray menu - Keypad hacking solver).
Anti AFK (via tray menu - The game will press Z every 10 minutes).
